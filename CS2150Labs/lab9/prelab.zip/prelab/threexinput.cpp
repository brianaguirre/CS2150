/**
Brian Aguirre
ba5bx
threexinput.cpp
November 15, 2014
*/

#include <string>
#include <iostream>
#include "timer.h"

using namespace std;

//GET METHOD:
extern "C" int threexinput(int);

/**  
LOGIC OF THE X86 CODE:
int threexplusone(int x){
	if (x == 1){
		return 0;
	}
	else if (x % 2 == 0){
		return threexplusone(x/2) + 1;
	}
	else{
		return threexplusone(3*x + 1) + 1;
	}
}
*/

int main(){
	//REQUIRED VARIABLES:
	int x;
	int steps;
	double time;
	timer t;


	//GET INPUT:
	cout << "Please enter a number:" << endl;
	cin >> x;

	//CALCULATES TIME:
	t.start();
	for (int i=0; i<steps; i++){
		threexplusone(x);
	}	
	t.stop();

	time = t.getTime();

	//OUTPUT RESULTS:
	cout << "Number of steps to reach 1: " << threexplusone(x) << endl;
	cout << "Time: " << (time/steps) << endl;

	return 0;

}


